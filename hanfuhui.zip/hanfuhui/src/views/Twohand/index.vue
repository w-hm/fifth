<template>
    <div class="wrap">
        <div class="box">
            <img src="https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1565781730&di=ef2f08d40854a68a2bfa3f4661475419&src=http://work.361ser.com/Content/ueditor/net/upload/image/20170918/6364134664818906458994681.jpg" alt="">
            <span>可惜哦，商品已经卖完啦，下次记得早点来呦～</span>
           
        </div>
    </div>
</template>
<script>
export default {
    name:"Twohand",
   
}
</script>
<style scoped> 
        .box{      
            background-color: #fff;  
            width: 100%;
            color: grey;
            display: flex;
            flex-direction: column;                
        }
        .box img{
            height: 6rem;;
        }
        .box span {
            padding:1rem 0.6rem;
        }
</style>