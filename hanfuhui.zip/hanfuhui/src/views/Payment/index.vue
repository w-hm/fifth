<template>
    <div  class="wrap">
        <div>
             <p>支付金额</p>
              <h3>{{goodsprice}}</h3>
              <p></p>
         </div>
       
    </div>
</template>
<script>
export default {
        name:"Payment"

        
}
</script>
<style scoped>

</style>