export default {
    path:"/store/:storeId",
    component:()=>import("@/views/Brand/store"),
   
}