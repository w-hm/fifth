export default {
    path:"/first",
    component:()=>import("@/views")
}