export default {
    path:"/twohand",
    component:()=>import("@/views/Twohand")
}