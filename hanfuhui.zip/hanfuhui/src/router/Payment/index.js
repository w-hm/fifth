export default {
    path:"/payment",
    component:()=>import("@/views/Payment")
}