export default {
    path:"/search",
    component:()=>import("@/views/Search")
}