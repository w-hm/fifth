export default {
    path:"/details",
    name:"details",
    component:()=>import("@/views/Details")
}