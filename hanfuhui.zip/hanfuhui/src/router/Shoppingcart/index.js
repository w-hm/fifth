export default {
    path:"/shoppingcart",
    name:"shoppingcart",
    component:()=>import("@/views/Shoppingcart")
}