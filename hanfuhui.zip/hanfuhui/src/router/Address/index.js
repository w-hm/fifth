export default {
    path:"/address",
    component:()=>import("@/views/Address"),

}