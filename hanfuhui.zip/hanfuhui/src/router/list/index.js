export default {
    path:"/list",
    name:"list",
    component:()=>import("@/views/Brand/list")
}