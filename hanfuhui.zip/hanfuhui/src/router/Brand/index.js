export default {
    path:"/brand",
    component:()=>import("@/views/Brand"),
   
}

// children:[
//     {
//         path:"/store",
//         component:()=>import("@/views/Brand/store")
//     }
// ]