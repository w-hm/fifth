export default {
    path:"/orderList",
    component:()=>import("@/views/OrderList"),
}