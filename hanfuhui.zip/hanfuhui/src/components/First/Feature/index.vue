<template>
    <div class="feature">
        <div class="con">
            更多专题  >
        </div>
    </div>
</template>
<script>
export default {
    name:"Feature"
}
</script>
<style scoped>

.feature{
  width: 100%;
  background-color: #fff;
  display: flex;
  justify-content: center;
  padding: 0.5rem;
}
.feature .con{
  border:2px solid #ff4466;
  width: 2.5rem;
  height: 0.8rem;
  border-radius: 5px;
  color: #ff4466;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>