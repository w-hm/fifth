第一步
git clone git项目地址
例如
git clone https://github.com/w-hm/hanfuhui_fe

cd hanfuhui_fe

//  做一下修改

git status     //  查看状态， 改了什么

git add .      // 把修改的添加到 git 列表 里

git commit -m "描述"      // 确认提交

git pull origin master     // 拉去最新的代码下来

git push origin master     // 将被动的git 推送到服务端

git pull origin master     // 拉去最新的代码下来
